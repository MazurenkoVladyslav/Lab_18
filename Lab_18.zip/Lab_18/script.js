class Shape {

    constructor(color) {
        this.color = color;
    }
}

class Circle extends Shape {

    constructor(color, radius) {

        super(color);
        this.radius = radius;
    }
    

    calculateArea() {
        return Math.PI * this.radius ** 2;
    }
}

class Rectangle extends Shape {

    constructor(color, width, height) {

        super(color);
        this.width = width;
        this.height = height;
    }
    

    calculateArea() {
        return this.width * this.height;
    }
}

const circle = new Circle('red', 9);
console.log(`Circle color: ${circle.color}`);
console.log(`Circle area: ${circle.calculateArea()}`);

const rectangle = new Rectangle('blue', 7, 10);
console.log(`Rectangle color: ${rectangle.color}`);
console.log(`Rectangle area: ${rectangle.calculateArea()}`);
